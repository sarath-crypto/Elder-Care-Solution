netcat -ul 8880
