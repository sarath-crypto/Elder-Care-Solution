g++ wificli.cpp udpc.cpp `pkg-config --cflags --libs opencv4` -g -o wificli
