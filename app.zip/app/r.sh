./ecsysapp /home/ecsys/v4/config.ini
