#include <stdio.h>  
#include <unistd.h> 
#include <iostream>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <time.h>

#include "global.h"
#include "udps.h"

#define  SERVER_PORT    "8880"
#define  SSID           "sarath_nivas"
#define  PASS           "land1234"

using namespace std;
 
bool exit_nw  = false;


int main(void){
	string myip,cmd;
	udps *pc = new udps(stoi(string(SERVER_PORT)));	
	pc->ssid = SSID;
	pc->pass = PASS;
	cout <<pc->myip <<endl;

	unsigned int s = time(NULL);
	while(!exit_nw){
		pc->recv();
		pc->process();
		switch(pc->sm){
		case(CONFIG):{
			pc->txfifo.clear();
			pdu p;
			p.type = INIT;
			string data  = pc->myip+":"+to_string(pc->myport)+":"+pc->ssid+":"+pc->pass;
			p.len = HEADER_LEN+data.length();
			memcpy(p.data,data.data(),data.length());
			pc->txfifo.push_back(p);
			break;
		}
		case(WIFI):{
			pdu p;
			p.type = CFG;
			p.len = HEADER_LEN;
			pc->txfifo.push_back(p);
			break;
		}
		case(KAL):{
			if((time(NULL)-s) > 10){
				pc->txfifo.clear();
				s = time(NULL);
				pdu p;
				p.type = KALV;
				p.len = HEADER_LEN;
				pc->txfifo.push_back(p);
			}
			break;
		}
		}
		pc->send();
	}	
	return 0;
}
