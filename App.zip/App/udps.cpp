#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>

#include <math.h>
#include <fstream>
#include <stddef.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <sstream>

#include <syslog.h>

#include "udps.h"

//#define	DEBUG		1

using namespace std;
extern bool ex;

udps::~udps(){
	close(sockfd);
}
udps::udps(unsigned short port){
	state = true;
	myport = port;
	if((sockfd = socket(AF_INET,SOCK_DGRAM, 0)) < 0 ){
        	state = false;
		return;
	}
	bzero(&seraddr,sizeof(seraddr));
	bzero(&cliaddr,sizeof(cliaddr));
	seraddr.sin_family  = AF_INET;
	seraddr.sin_addr.s_addr = INADDR_ANY;
	seraddr.sin_port = htons(port);
	if(bind(sockfd, (const struct sockaddr *)&seraddr,sizeof(seraddr)) < 0 ){ 
        	state = false;
		return;
    	}	 
	con = false;
	sm = STOP;
	beacon_try = 0;
	timeout.tv_sec = 0;
        timeout.tv_usec = 10;
        setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));

        int fd;
        struct ifreq ifr;
        fd = socket(AF_INET, SOCK_DGRAM, 0);
        ifr.ifr_addr.sa_family = AF_INET;
        strncpy(ifr.ifr_name,"wlan0", IFNAMSIZ-1);
        ioctl(fd, SIOCGIFADDR, &ifr);
        close(fd);
	myip = string(inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
}

void udps::recv(void){
	int n = -1;
	socklen_t len  = sizeof(cliaddr);
	unsigned char buffer[BUF_LEN];
	n = recvfrom(sockfd,(char *)buffer,BUF_LEN,MSG_WAITALL,( struct sockaddr *) &cliaddr,&len); 
	if(n > 0){
		pdu p;
		memcpy((void *)&p,buffer,n);
		if(n == p.len){
#ifdef	DEBUG
			printf("%s RECV->BYTES:%d TYPE:%d\n",inet_ntop(AF_INET,&cliaddr.sin_addr,(char *)&buffer,BUF_LEN),n,(int)p.type);
#endif
			rxfifo.push_back(p);
		}
	}
}
void udps::send(void){
	if(txfifo.size()){
		pdu p = txfifo[0];
		int n = -1;
		n = sendto(sockfd,(const char *)&p,p.len,MSG_CONFIRM, (const struct sockaddr *) &cliaddr,sizeof(cliaddr)); 
		if(n == p.len){
#ifdef	DEBUG
			unsigned char buffer[BUF_LEN];
			printf("%s SEND->BYTES:%d TXQ:%d TYPE:%d\n", inet_ntop(AF_INET,&cliaddr.sin_addr,(char *)&buffer,BUF_LEN),n,txfifo.size(),(int)p.type);
#endif
			if(txfifo.size())txfifo.erase(txfifo.begin());
		}
	}
}
void udps::process(void){
	if(rxfifo.size()){
		pdu p = rxfifo[0];
		switch(p.type){
		case(INIT):{
			sm = STOP;
			string data((const char *)&p.data,p.len-HEADER_LEN);
			if(!data.compare(INIT_DATA))sm = CONFIG;
			con = false;
			break;
		}
		case(CFG):{
			string sdata  = myip+":"+to_string(myport)+":"+ssid+":"+pass;
			string rdata((const char *)&p.data,p.len-HEADER_LEN);
			if(!sdata.compare(rdata))sm = WIFI;
			break;
		}
		case(ACK):{
			sm = KAL;
			break;
		}
		case(KALV):{
			beacon_try = 0;
			con =  true;
			break;
		}
		}
		if(rxfifo.size())rxfifo.erase(rxfifo.begin());
	}
}
