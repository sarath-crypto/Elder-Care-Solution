#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>

#include <math.h>
#include <fstream>
#include <stddef.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <sstream>

#include "udps.h"

//#define	DEBUG		1

using namespace std;
extern bool ex;

udps::~udps(){
	close(sockfd);
}

udps::udps(){
	state = true;
	if((sockfd = socket(AF_INET,SOCK_DGRAM, 0)) < 0 ){
        	state = false;
		return;
	}
	bzero(&seraddr,sizeof(seraddr));
	bzero(&cliaddr,sizeof(cliaddr));
	seraddr.sin_family  = AF_INET;
	seraddr.sin_addr.s_addr = INADDR_ANY;
	//inet_pton(AF_INET, "192.168.1.105", &(seraddr.sin_addr));
	seraddr.sin_port = htons(stoi(string(PORT)));
	if(bind(sockfd, (const struct sockaddr *)&seraddr,sizeof(seraddr)) < 0 ){ 
        	state = false;
		return;
    	}	 
	con = false;
	sm = STOP;
	beacon_try = 0;
	timeout.tv_sec = 0;
        timeout.tv_usec = 10;
        setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
	

	string ip;
	getip(ip);

	cfg.push_back(SSID);
	cfg.push_back(PASS);
	cfg.push_back(ip);
	cfg.push_back(PORT);
	cfg.push_back(FILE_BEEP);
	cfg.push_back(FILE_BLIP);
	cfg.push_back(FILE_RING);
	cfg.push_back(FILE_SZ);
}

void udps::getip(string &ip){
        int fd;
        struct ifreq ifr;
        fd = socket(AF_INET, SOCK_DGRAM, 0);
        ifr.ifr_addr.sa_family = AF_INET;
        strncpy(ifr.ifr_name, "wlan0", IFNAMSIZ-1);
        ioctl(fd, SIOCGIFADDR, &ifr);
        close(fd);
	ip = string(inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
}

void udps::recv(void){
	int n = -1;
	socklen_t len  = sizeof(cliaddr);
	unsigned char buffer[BUF_LEN];
	n = recvfrom(sockfd,(char *)buffer,BUF_LEN,MSG_WAITALL,( struct sockaddr *) &cliaddr,&len); 
	if(n > 0){
		pdu p;
		memcpy((void *)&p,buffer,n);
		if(n == p.len){
#ifdef	DEBUG
			printf("%s RECV->BYTES:%d TYPE:%d\n",inet_ntop(AF_INET,&cliaddr.sin_addr,(char *)&buffer,BUF_LEN),n,(int)p.pdu_type);
#endif
			if(p.pdu_type == INIT){
				beacon_try = 0;
				con = true;
				txfifo.clear();
				txfifo.push_back(p);
				sm = CFG;
			}else rxfifo.push_back(p);
		}
	}
}
void udps::send(void){
	if(txfifo.size()){
		pdu p = txfifo[0];
		int n = -1;
		n = sendto(sockfd,(const char *)&p,p.len,MSG_CONFIRM, (const struct sockaddr *) &cliaddr,sizeof(cliaddr)); 
		if(n == p.len){
#ifdef	DEBUG
			printf("SEND->BYTES:%d TXQ:%d TYPE:%d\n",n,txfifo.size(),(int)p.pdu_type);
#endif
			txfifo.erase(txfifo.begin());
			sleep(1);
		}
	}
}
void udps::process(void){
	if(rxfifo.size()){
		pdu p = rxfifo[0];
		switch(p.pdu_type){
		case(GCFG):{
			if(sm != CFG)break;
			string msg;
		        msg.append((char *)p.data,(size_t)p.len);
			stringstream in(msg);
			vector<string>data;
			while(std::getline(in,msg,':'))data.push_back(msg);
			bool valid = true;
			for(unsigned int  i = 0;i < cfg.size(); i++)if(cfg[i].compare(data[i]))valid = false;
			p.pdu_type = SCFG;
			if(!valid){
				/*
				//set new config verify		
				p.len = HEADER_LEN;
				txfifo.push_back(p);
				*/
			}else{
				p.len = HEADER_LEN;
				txfifo.push_back(p);
				sm = KAL;
			}
			break;
		}
		case(KALV):{
			if(sm != KAL)break;
			beacon_try = 0;
			break;
		}
		}
		rxfifo.erase(rxfifo.begin());
	}
}
