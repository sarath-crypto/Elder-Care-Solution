g++ dbcam.cpp syscam.cpp `pkg-config --cflags --libs opencv4` -llccv  -lmysqlcppconn -Wno-psabi -o dbcam
