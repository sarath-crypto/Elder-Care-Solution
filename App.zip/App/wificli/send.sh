echo "hi" | socat - udp4-sendto:192.168.1.100:8880
