tail -100 /var/log/syslog | grep ecsysapp
ps -alx | grep ecsysapp
