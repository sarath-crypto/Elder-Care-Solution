#ifndef _BLE_H_
#define _BLE_H_

#include <exception>
#include <iostream>
#include <cstdint>
#include <map>
#include <regex>
#include <string>
#include <sdbus-c++/sdbus-c++.h>

#define	BLUEZ_DBUS_NAME "org.bluez"
#define DEFAULT_ADAPTER_PATH "/org/bluez/hci0"

using namespace std;

class ble{
	bool isAdapterPoweredOn(void);
	void tryPoweringOnAdapter(void);
	void print_adapter_details(void);
	void get_all_managed_objects(void);
	string get_advertising_capable_adapter_path(void);
public:
	void connect_to_device_using_address(string);
	void disconnect_from_device_using_address(string);
	ble();
	~ble();
	bool speaker_en;
	bool mouse_en;
};

#endif
