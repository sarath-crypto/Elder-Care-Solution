#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <iostream>
#include <map>
#include <regex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include <exception>
#include <iostream>
#include <cstdint>
#include <map>
#include <regex>
#include <string>
#include <sdbus-c++/sdbus-c++.h>
#include <string>

#include "ble.h"

//#define DEBUG	1

using namespace std;

ble::ble(){
	speaker_en = false;
	mouse_en = false;
	if(!isAdapterPoweredOn())tryPoweringOnAdapter();
#ifdef 	DEBUG
	string adv = get_advertising_capable_adapter_path();
	cout << adv <<endl;
	get_all_managed_objects();
	print_adapter_details();
#endif
}

ble::~ble(){

}

bool ble::isAdapterPoweredOn(void){
	try {
		return sdbus::createProxy("org.bluez",DEFAULT_ADAPTER_PATH)->getProperty("Powered").onInterface("org.bluez.Adapter1").get<bool>();
	} catch (std::exception &e) {
		std::cerr << "WARN: " << e.what() << std::endl;
		return false;
	}
}

void ble::tryPoweringOnAdapter(void){
	auto adapter = sdbus::createProxy("org.bluez",DEFAULT_ADAPTER_PATH);
	adapter->callMethod("Set").onInterface("org.freedesktop.DBus.Properties").withArguments("org.bluez.Adapter1", "Powered", sdbus::Variant(true));
}

void ble::connect_to_device_using_address(string address){
	if (std::regex_match(address,std::regex("([\\[0-9\\]\\[A-F\\]]{2}:){5}[\\[0-9\\]\\[A-F\\]]{2}"))) {
		std::replace(address.begin(), address.end(), ':', '_');
		auto device_path = DEFAULT_ADAPTER_PATH + string("/dev_") + address;
		auto device = sdbus::createProxy("org.bluez", device_path);
		try {
			device->callMethod("Connect").onInterface("org.bluez.Device1").withTimeout(std::chrono::seconds(1));
		} catch (sdbus::Error &e) {
#ifdef 	DEBUG
			std::cerr << "ERROR: " << e.what() << endl;
#endif
			return;
		}
	} else {
		cout << "Invalid address: " << address << ". Address should be of the form: XX:XX:XX:XX:XX:XX" << endl;
	}
}

void ble::disconnect_from_device_using_address(string address){
	if (std::regex_match(address,std::regex("([\\[0-9\\]\\[A-F\\]]{2}:){5}[\\[0-9\\]\\[A-F\\]]{2}"))) {
		std::replace(address.begin(), address.end(), ':', '_');
		auto device_path = DEFAULT_ADAPTER_PATH + string("/dev_") + address;
		auto device = sdbus::createProxy("org.bluez", device_path);
		device->callMethod("Disconnect").onInterface("org.bluez.Device1");
	} else {
		cout << "Invalid address: " << address << ". Address should be of the form: XX:XX:XX:XX:XX:XX" << endl;
	}
}

string ble::get_advertising_capable_adapter_path(void){
	auto results = std::map<sdbus::ObjectPath,std::map<std::string, std::map<std::string, sdbus::Variant>>>();
	sdbus::createProxy("org.bluez", "/")->callMethod("GetManagedObjects").onInterface("org.freedesktop.DBus.ObjectManager").storeResultsTo(results);
	for (const auto &obj : results) {
		auto it = obj.second.find("org.bluez.LEAdvertisingManager1");
		if (it != obj.second.cend()) {
			return obj.first;
		}
	}
	throw std::logic_error("No adapter implementing org.bluez.LEAdvertisingManager1 found !");
}

void ble::print_adapter_details(void){
	cout << '\n' << __func__ << "\n========================" << endl;
	auto adapter = sdbus::createProxy(BLUEZ_DBUS_NAME,DEFAULT_ADAPTER_PATH);
	auto dict = map<string, sdbus::Variant>();
	adapter->callMethod("GetAll").onInterface("org.freedesktop.DBus.Properties").withArguments("org.bluez.Adapter1").storeResultsTo(dict);

	for (const auto &p : dict) {
		cout << "* " << p.first << ": ";

		auto type = p.second.peekValueType();
		if (type == "s") {
			cout << p.second.get<string>();
		} else if (type == "u") {
			cout << p.second.get<uint32_t>();
		} else if (type == "b") {
			cout << std::boolalpha << p.second.get<bool>();
		} else if (type == "as") {
			auto vec = p.second.get<vector<string>>();
			cout << "[ ";
			for (auto &s : vec) {
				cout << s << ", ";
			}
			cout << " ]";
		} else {
			cout << type;
		}

		cout << endl;
	}
}

void ble::get_all_managed_objects(void){
	cout << '\n' << __func__ << "\n========================" << endl;
	auto result = map<sdbus::ObjectPath,map<string,map<string,sdbus::Variant>>>();
	auto adapter = sdbus::createProxy("org.bluez", "/");
	adapter->callMethod("GetManagedObjects").onInterface("org.freedesktop.DBus.ObjectManager").storeResultsTo(result);

	cout << "Managed Objects:\n";
	for (auto &p : result) {
		cout << p.first << ": ";
		if (p.first == DEFAULT_ADAPTER_PATH) {
			cout << "Adapter";
		} else if (p.first.find("/org/bluez/hci0/dev_") == 0 && p.first.length() == sizeof("/org/bluez/hci0/dev_XX_XX_XX_XX_XX_XX") - 1) {
			cout << "Device\n";
			cout << "\tName: \"" << p.second["org.bluez.Device1"]["Alias"].get<string>() << "\"\n";
			cout << "\tAddress: \""<< p.second["org.bluez.Device1"]["Address"].get<string>()<< "\"\n";
			cout << "\tInterfaces:\n";
			for (auto &dev_p : p.second) {
				cout << "\t\t" << dev_p.first << '\n';
			}
		} else {
			cout << "Ignore";
		}
		cout << endl;
	}
}
