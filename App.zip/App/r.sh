./ecsysapp /home/ecsys/v3/config.ini
