pkill ecsysapp -9
