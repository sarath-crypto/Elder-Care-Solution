wlan=$(nmcli connection show --active | grep "wlan0" | awk '{print $NF}')
if test "$wlan" = "wlan0"
then
        sudo iw dev wlan0 interface add wlan1 type __ap
        sleep 5
        sudo nmcli connection up ecsysappi
fi

while true
do 
	cmd=$(pgrep ecsysapp)
	if [ -z "$cmd" ]; then
		/home/ecsys/v4/ecsysapp /home/ecsys/v4/config.ini
	fi
	sleep 30
done
