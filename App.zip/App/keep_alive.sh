while true
do 
	cmd=$(pgrep ecsysapp)
	if [ -z "$cmd" ]; then
		/home/ecsys/v2/ecsysapp /home/ecsys/v2/config.ini
	fi
	sleep 30
done
