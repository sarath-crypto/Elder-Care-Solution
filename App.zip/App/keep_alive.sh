while true
do 
	cmd=$(pgrep ecsysapp)
	if [ -z "$cmd" ]; then
		/home/ecsys/v2/ecsysapp
	fi
	sleep 30
done
