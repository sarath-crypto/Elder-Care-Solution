pacmd list-sources|awk '/index:/ {print $0} /name:/ {print $0};'

NumberOfEvents=$(ls /dev/input | grep -c event*)

i=0
while [ $i -lt $NumberOfEvents ]; do
    Name=$(cat /sys/class/input/event$i/device/name)
    echo event$i $Name
    let i=i+1
done

sudo nmcli connection add type wifi ifname wlan0 con-name ecsysappi autoconnect yes ssid ecsysappi
sudo nmcli connection modify ecsysappi 802-11-wireless.mode ap 802-11-wireless.band bg ipv4.method shared
sudo nmcli connection modify ecsysappi wifi-sec.key-mgmt wpa-psk
sudo nmcli connection modify ecsysappi wifi-sec.psk "12345678"
sudo nmcli connection up ecsysappi
sudo nmcli connection modify ecsysappi connection.autoconnect yes
